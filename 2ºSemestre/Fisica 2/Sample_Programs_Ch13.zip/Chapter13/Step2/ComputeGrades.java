/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 13 Sample Development: Compute Grades for Undergraduate
                                    and Graduate Students

    File: Step2/ComputeGrades.java

*/


//-----------------------  STEP 2 -------------------------//

/**
 *   Class ComputeGrades
 *
 *   The top level object for managing all other objects in the program
 *
 */
class ComputeGrades extends MainWindow {

//----------------------------------
//    Data Members
//----------------------------------

    /**
     * The default size for the roster array
     */
    private static final int DEFAULT_SIZE = 25;

    /**
     * An outputbox for displaying the result
     */
    private OutputBox   outputBox;

    /**
     * An array of Student for maintaining student info
     */
    private Student[]   roster;

    /**
     * The number student information loaded from a file
     */
    private int         studentCount;

//----------------------------------
//    Constructors
//----------------------------------

    /**
     * Default constructor
     */
    public ComputeGrades() {
        this (DEFAULT_SIZE);
    }

    /**
     * Constructs this object with the designated size
     * for an array.
     *
     * @param arraySize the size of the roster array
     */
    public ComputeGrades(int arraySize) {
        super();   // an explicit call to the supercalss constructor

        outputBox   = new OutputBox(this);

        roster      = new Student[arraySize];

        studentCount = 0;
    }

//-----------------------------------
// Main
//-----------------------------------
    public static void main(String[] args) {
      ComputeGrades gradeComputer = new ComputeGrades();
      gradeComputer.processData();
    }

//-------------------------------------------------
//      Public Methods:
//
//          void    processData   (           )
//
//------------------------------------------------

    /**
     * Loads the data from a file, computes the grades,
     * and display the result.
     *
     */
    public void processData() {
         setVisible(true);
         outputBox.setVisible(true);

         boolean success = readData();

         if (success) {
            computeGrade();
            printResult();
         } else {
            outputBox.println("File Input Error");
         }
    }

//-------------------------------------------------
//      Private Methods:
//
//        void        computeGrade    (     )
//        void        printResult     (     )
//        boolean     readData        (     )
//
//------------------------------------------------

    /**
     * Scans through the roster array and computes
     * the course grades.
     *
     */
    private void computeGrade() {
        outputBox.println("Inside computeGrade");  //TEMP
    }

    /**
     * Displays the result in an outputBox.
     *
     */
    private void printResult() {
        for (int i = 0; i < studentCount; i++) {

            //print one student

            outputBox.print(roster[i].getName());

            for (int testNum = 1; testNum <= Student.NUM_OF_TESTS; testNum++) {

                outputBox.print("\t" + roster[i].getTestScore(testNum));
            }

            outputBox.println("\t" + roster[i].getCourseGrade());
       }

    }

    /**
     * Opens a textfile, read in data, and
     * construct the roster array.
     *
     * @return true if the operation is successful
     *
     */
    private boolean readData() {
        outputBox.println("Inside readData");  //TEMP


        //TEMP
        //     Create a temporary roster array to
        //     test the printResult method.
        //
        for (int i = 0; i < 15; i++) {
            roster[i] = new UndergraduateStudent();
            roster[i].setName("Undergrad # " + i);

            roster[i].setTestScore(1, 70 + i);
            roster[i].setTestScore(2, 80 + i);
            roster[i].setTestScore(3, 90 + i);

        }

        for (int i = 15; i < DEFAULT_SIZE; i++) {
            roster[i] = new GraduateStudent();
            roster[i].setName("Grad # " + i);

            roster[i].setTestScore(1, 80 + i);
            roster[i].setTestScore(2, 85 + i);
            roster[i].setTestScore(3, 90 + i);

        }

        studentCount = DEFAULT_SIZE;

        return true;

    }

}