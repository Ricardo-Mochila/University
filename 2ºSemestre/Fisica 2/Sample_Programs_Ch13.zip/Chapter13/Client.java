/*
    Introduction to OOP with Java (5th Ed), McGraw-Hill

    Wu/Otani

    Chapter 13 Sample Program: The client class to illustrate inheritance
                               member accessibility.

    File: Client.java

*/
import one.*;
import two.*;

public class Client {
	
	public void test( ) {
		
		Super mySuper = new Super( );
		Sub   mySub   = new Sub( );
		
		int i = mySuper.public_Super_Field;
		int j = mySub.public_Super_Field; //inherited by Sub
		int k = mySub.public_Sub_Field;
		
		//Following statements are invalid
//		int l = mySuper.private_Super_Field;
//		int m = mySub.private_Super_Field; //inherited by Sub
//		int n = mySub.private_Sub_Field;
		
		//Following statements are invalid
//		int o = mySuper.protected_Super_Field;
//		int p = mySub.protected_Super_Field; //inherited by Sub
//		int q = mySub.protected_Sub_Field;
	}

}
