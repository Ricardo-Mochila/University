

public class Main1Graphics {
    public static void main(String[] args) {
        Fusion1Graphics fusionGraphics = new Fusion1Graphics();
        fusionGraphics.input_num();
        fusionGraphics.input_color();
        fusionGraphics.set_grid();
        fusionGraphics.gameOver(0,0);
        while(!fusionGraphics.state){
            fusionGraphics.set_grid();
            fusionGraphics.gameOver(0,0);
        }
        fusionGraphics.get_grid();



    }


}
