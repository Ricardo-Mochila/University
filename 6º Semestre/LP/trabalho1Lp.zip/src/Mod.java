public class Mod extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "Mod";
    }
}