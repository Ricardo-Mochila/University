public class Mult extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "Mult";
    }
}