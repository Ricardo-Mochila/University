
public class Add extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "Add";
    }
}