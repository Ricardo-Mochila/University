
public abstract class Instrucao {
    public abstract void execute();
    public abstract String toString();

}