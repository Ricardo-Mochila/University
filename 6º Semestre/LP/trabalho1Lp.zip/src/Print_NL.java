
public class Print_NL extends Instrucao{


    @Override
    public void execute(){

    }

    @Override
    public String toString() {
        return "\n";
    }
}