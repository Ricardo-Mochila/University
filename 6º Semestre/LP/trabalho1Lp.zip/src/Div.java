public class Div extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "Div";
    }
}