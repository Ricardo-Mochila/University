public class Sub extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "Sub";
    }
}