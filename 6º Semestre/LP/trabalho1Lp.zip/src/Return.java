
public class Return extends Instrucao {

    @Override
    public void execute() {

    }

    @Override
    public String toString() {
        return "return";
    }
}