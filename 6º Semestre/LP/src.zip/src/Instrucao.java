
public abstract class Instrucao extends TISC{

    public abstract void execute();
    public abstract String toString();
}