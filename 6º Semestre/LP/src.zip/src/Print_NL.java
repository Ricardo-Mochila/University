
public class Print_NL extends Instrucao{


    @Override
    public void execute(){
        System.out.print("\n");
    }

    @Override
    public String toString() {
        return "\n";
    }
}