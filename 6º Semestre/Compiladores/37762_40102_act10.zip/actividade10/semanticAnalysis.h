

void errorPrint();
bool check_types(int op, int type1, int type2);
void d_decl_ant(d_decl d);
void d_decls_ant(d_decls ds);
e_exp t_exp_ant(e_exp e);