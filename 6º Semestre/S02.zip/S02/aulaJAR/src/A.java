package so2;

public class A {
    
    public static void main(String[] args) {
        B obj= new B(2);
        System.out.println("O objeto B guarda o valor: "+ obj.getValue() );
    }
    
}