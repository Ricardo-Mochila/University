Ver os comandos no ficheiro Makefile ou no moodle.

Para mais opções:
    $ man jar
ou visite 
    https://docs.oracle.com/javase/tutorial/deployment/jar/
