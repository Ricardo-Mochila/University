package par3cc;

/**
 *
 * @author jsaias
 */
public class Par3cc {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }
    
}
