package trabalho1;

import java.rmi.server.UnicastRemoteObject;
import java.sql.ResultSet;
import java.sql.Statement;

public class Invocations extends UnicastRemoteObject implements InvocationsInterface, java.io.Serializable {

    // deve existir um construtor
    public Invocations() throws java.rmi.RemoteException {
        super();
    }
    
    /**
     * devolve a primeira palavra da frase recebida
     *
     * @param s
     * @return
     * @throws java.rmi.RemoteException
     */
    
    public void registarProduto(String produto, String loja) throws java.rmi.RemoteException, Exception{
        PostgresConnector pc = new PostgresConnector( "localhost", "Produtos", "Admin", "123");
        
        pc.connect();
        Statement stmt = pc.getStatement();

        try { 
            stmt.executeUpdate("insert into produto values('"+produto+"','"+loja+"')");
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problems on insert...");
       }
    }

    public String consultarProduto(String produto) throws java.rmi.RemoteException, Exception{
        PostgresConnector pc = new PostgresConnector( "localhost", "Produtos", "Admin", "123");
        
        pc.connect();
        Statement stmt = pc.getStatement();
        ResultSet result;
        String output = "";
        try {
            result = stmt.executeQuery("Select * from produto where nome = '"+produto+"'");
            while (result.next()) {
                output += "- " + result.getString(1) + " na loja " +result.getString(2) + "\n";
            }
            return output;
        }
        catch (Exception e) {
            e.printStackTrace();
            System.err.println("Problems on insert...");
       }
       return null;
    }
    /**
     * devolve um vector com cada palavra da expressao recebida
     *
     * @param s
     * @return 
     * @throws java.rmi.RemoteException
     */
    public java.util.Vector<String> divide(String s) throws java.rmi.RemoteException {
        System.err.println("invocacao divide() com: " + s);
        java.util.Vector<String> v = new java.util.Vector<String>();
        String s2 = s.trim();
    
        String[] s2pals = s2.split(" ");

        for (int i = 0; i < s2pals.length; i++) {
            v.add(s2pals[i]);       // adiciona a palavra i
        }
        return v;
    }

}
