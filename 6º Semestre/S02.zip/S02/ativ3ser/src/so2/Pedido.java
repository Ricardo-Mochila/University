package so2;

public abstract class Pedido {
}