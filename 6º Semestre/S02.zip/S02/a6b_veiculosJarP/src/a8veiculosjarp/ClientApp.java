package a8veiculosjarp;

/**
 *
 * @author jsaias
 */
public class ClientApp {
    public static void main(String[] args) {
        // inicialize o Cliente Aqui... pode por exemplo chamar o metodo main() da classe do servidor
        so2.VeiculosClient.main(args);
    
    }
}
