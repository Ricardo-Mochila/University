package trabalho1; 

/**
 *
 * @author ricardomochila, inesverissimo
 */

public interface FileSavingInterface {

    public void save (int id);

    public int load ();

}